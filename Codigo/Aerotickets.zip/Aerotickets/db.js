// =============================================
// IMPORTAR LIBRERÍA MYSQL2
// =============================================

// mysql2 permite conectar Node.js con MySQL
const mysql = require('mysql2');


// =============================================
// CREAR POOL DE CONEXIONES
// =============================================

// createPool crea un grupo de conexiones reutilizables
// Esto mejora el rendimiento del servidor
const pool = mysql.createPool({

    // Dirección del servidor MySQL
    // localhost significa que MySQL está instalado en el mismo computador
    host: 'localhost',

    // Usuario de MySQL
    // "root" es el usuario administrador por defecto
    user: 'root',

    // Contraseña del usuario de MySQL
    password: 'Admin123',

    // Nombre de la base de datos que se va a usar
    database: 'aerotickets',

    // Esperar conexiones disponibles si todas están ocupadas
    waitForConnections: true,

    // Número máximo de conexiones simultáneas
    connectionLimit: 10
});


// =============================================
// CONVERTIR EL POOL A PROMESAS
// =============================================

// promise() permite usar async/await
// Esto hace el código más limpio y fácil de leer
const db = pool.promise();


// =============================================
// PROBAR CONEXIÓN A LA BASE DE DATOS
// =============================================

// Se ejecuta una consulta simple para verificar que MySQL funciona
db.query('SELECT 1')

    // Si la conexión es exitosa
    .then(() => console.log(
        'Conectado a MySQL correctamente'
    ))

    // Si ocurre un error
    .catch(err => console.error(
        'Error al conectar a MySQL:',
        err.message
    ));


// =============================================
// EXPORTAR CONEXIÓN
// =============================================

// Permite usar "db" en otros archivos como server.js
module.exports = db;