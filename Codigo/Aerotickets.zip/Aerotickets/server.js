const express = require('express');
const session = require('express-session');
const path = require('path');
const db = require('./db');

const app = express();

// =============================================
// MIDDLEWARES
// =============================================
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));
app.use(session({
    secret: 'aerotickets_secret',
    resave: false,
    saveUninitialized: false,
    cookie: { secure: false }
}));

// Middleware de autenticación
function auth(req, res, next) {
    if (!req.session.user) {
        return res.status(401).json({ error: 'Debes iniciar sesión' });
    }
    next();
}

// =============================================
// RUTAS DE AUTENTICACIÓN
// =============================================

// Registrar usuario
app.post('/api/auth/register', async (req, res) => {
    const { nombre, correo, contrasena } = req.body;

    if (!nombre || !correo || !contrasena) {
        return res.status(400).json({ error: 'Todos los campos son obligatorios' });
    }

    try {
        const [existe] = await db.query(
            'SELECT id FROM usuarios WHERE correo = ?', [correo]
        );

        if (existe.length > 0) {
            return res.status(409).json({ error: 'El correo ya está registrado' });
        }

        await db.query(
            'INSERT INTO usuarios (nombre, correo, contrasena) VALUES (?, ?, ?)',
            [nombre, correo, contrasena]
        );

        res.status(200).json({ mensaje: 'Usuario registrado correctamente' });

    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Iniciar sesión
app.post('/api/auth/login', async (req, res) => {
    const { correo, contrasena } = req.body;

    if (!correo || !contrasena) {
        return res.status(400).json({ error: 'Correo y contraseña son obligatorios' });
    }

    try {
        const [rows] = await db.query(
            'SELECT id, nombre, correo, rol FROM usuarios WHERE correo = ? AND contrasena = ?',
            [correo, contrasena]
        );

        if (rows.length === 0) {
            return res.status(401).json({ error: 'Credenciales incorrectas' });
        }

        req.session.user = rows[0];
        res.status(200).json({ mensaje: 'Sesión iniciada', usuario: req.session.user });

    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Cerrar sesión
app.post('/api/auth/logout', (req, res) => {
    req.session.destroy();
    res.status(200).json({ mensaje: 'Sesión cerrada' });
});

// Consultar sesión activa
app.get('/api/auth/me', (req, res) => {
    if (req.session.user) {
        res.status(200).json(req.session.user);
    } else {
        res.status(200).json(null);
    }
});

// =============================================
// RUTAS DE VUELOS
// =============================================

// Listar vuelos con filtros opcionales
app.get('/api/vuelos', async (req, res) => {
    const { origen, destino, fecha, precio_max } = req.query;

    try {
        let query = "SELECT * FROM vuelos WHERE estado = 'disponible'";
        const params = [];

        if (origen) {
            query += ' AND origen LIKE ?';
            params.push(`%${origen}%`);
        }
        if (destino) {
            query += ' AND destino LIKE ?';
            params.push(`%${destino}%`);
        }
        if (fecha) {
            query += ' AND fecha_salida = ?';
            params.push(fecha);
        }
        if (precio_max) {
            query += ' AND precio <= ?';
            params.push(precio_max);
        }

        const [rows] = await db.query(query, params);
        res.status(200).json(rows);

    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Consultar detalle de un vuelo
app.get('/api/vuelos/:id', async (req, res) => {
    try {
        const [rows] = await db.query(
            'SELECT * FROM vuelos WHERE id = ?', [req.params.id]
        );

        if (rows.length === 0) {
            return res.status(404).json({ error: 'Vuelo no encontrado' });
        }

        res.status(200).json(rows[0]);

    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// =============================================
// RUTAS DE TIQUETES
// =============================================

// Comprar tiquete
app.post('/api/tiquetes', auth, async (req, res) => {
    const { vuelo_id, cantidad_pasajeros } = req.body;
    const usuario_id = req.session.user.id;

    if (!vuelo_id || !cantidad_pasajeros) {
        return res.status(400).json({ error: 'Datos incompletos' });
    }

    try {
        const [vuelos] = await db.query(
            "SELECT * FROM vuelos WHERE id = ? AND estado = 'disponible'", [vuelo_id]
        );

        if (vuelos.length === 0) {
            return res.status(400).json({ error: 'Vuelo no disponible' });
        }

        const vuelo = vuelos[0];

        if (vuelo.sillas_disponibles < cantidad_pasajeros) {
            return res.status(400).json({ 
                error: `Solo quedan ${vuelo.sillas_disponibles} sillas disponibles` 
            });
        }

        const precio_total = vuelo.precio * cantidad_pasajeros;

        await db.query(
            'INSERT INTO tiquetes (usuario_id, vuelo_id, cantidad_pasajeros, precio_total) VALUES (?, ?, ?, ?)',
            [usuario_id, vuelo_id, cantidad_pasajeros, precio_total]
        );

        res.status(200).json({ 
            mensaje: 'Tiquete comprado correctamente', 
            precio_total 
        });

    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Historial de compras
app.get('/api/tiquetes/historial', auth, async (req, res) => {
    const usuario_id = req.session.user.id;

    try {
        const [rows] = await db.query(`
            SELECT 
                t.id,
                t.cantidad_pasajeros,
                t.precio_total,
                t.fecha_compra,
                t.estado,
                v.origen,
                v.destino,
                v.fecha_salida,
                v.hora_salida,
                v.aerolinea
            FROM tiquetes t
            INNER JOIN vuelos v ON t.vuelo_id = v.id
            WHERE t.usuario_id = ?
            ORDER BY t.fecha_compra DESC
        `, [usuario_id]);

        res.status(200).json(rows);

    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// =============================================
// INICIAR SERVIDOR
// =============================================
app.listen(3000, () => {
    console.log('AeroTickets -> http://localhost:3000');
});